<?php

class Variables
{
    public $BASE_URL = '/web/sale/';
    public $ASSETS_URL = '/web/sale/assets/';

    //PUBLIC VARIABLES
    public $userData = [];
    public $masterData = [];
    public $content = "/content";
    public $load = "/load";

    public $stafData = [];
    public $setting = [];
}
