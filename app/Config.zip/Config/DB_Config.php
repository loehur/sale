<?php

class DB_Config
{
    protected $db_host;
    protected $db_user;
    protected $db_pass;
    protected $db_name;

    public function __construct($db = 1)
    {
        switch ($db) {
            case 1:
                $this->db_host = 'localhost';
                $this->db_user = 'root';
                $this->db_pass = '';
                $this->db_name = 'sale';
                break;
        }
    }
}
